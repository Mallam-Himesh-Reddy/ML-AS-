import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler

# Load Data
def load_data(file_path, stock_sheet, thyroid_sheet):
    stock_data = pd.read_excel(file_path, sheet_name=stock_sheet)
    thyroid_data = pd.read_excel(file_path, sheet_name=thyroid_sheet)
    return stock_data, thyroid_data

# Data Cleaning
def clean_data(df):
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    categorical_cols = df.select_dtypes(exclude=[np.number]).columns

    df[numeric_cols] = df[numeric_cols].apply(
        lambda x: x.fillna(x.median() if ((x - x.mean()).abs() > 3 * x.std()).sum() > 0 else x.mean())
    )
    df[categorical_cols] = df[categorical_cols].apply(lambda x: x.fillna(x.mode()[0]))
    return df, numeric_cols

# Data Normalization
def normalize_data(df, numeric_cols):
    scaler = MinMaxScaler()
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])
    return df

# Similarity Metrics
def calculate_similarity(vec1, vec2):
    f11 = np.sum(vec1 & vec2)
    f00 = np.sum(~vec1 & ~vec2)
    f01 = np.sum(~vec1 & vec2)
    f10 = np.sum(vec1 & ~vec2)

    jc = f11 / (f01 + f10 + f11)
    smc = (f11 + f00) / (f00 + f01 + f10 + f11)
    cosine_sim = np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

    return jc, smc, cosine_sim

# Similarity Matrix
def generate_similarity_matrix(df, numeric_cols, sample_size=20):
    sim_matrix = np.zeros((sample_size, sample_size))
    for i in range(sample_size):
        for j in range(sample_size):
            vec1 = df.iloc[i, :].astype(bool)
            vec2 = df.iloc[j, :].astype(bool)
            vec1_full = df.loc[i, numeric_cols].values.astype(np.float64)
            vec2_full = df.loc[j, numeric_cols].values.astype(np.float64)

            jc, smc, cosine_sim = calculate_similarity(vec1, vec2)
            sim_matrix[i, j] = (jc + smc + cosine_sim) / 3
    return sim_matrix

# Visualization
def plot_similarity_matrix(sim_matrix):
    plt.figure(figsize=(12, 8))
    sns.heatmap(sim_matrix, annot=True, cmap='coolwarm', fmt='.2f',
                cbar_kws={'label': 'Similarity'}, linewidths=0.5,
                xticklabels=range(1, sim_matrix.shape[0] + 1),
                yticklabels=range(1, sim_matrix.shape[0] + 1))

    plt.title('Similarity Matrix of Thyroid Data', fontsize=16)
    plt.xlabel('Sample Index', fontsize=14)
    plt.ylabel('Sample Index', fontsize=14)
    plt.tight_layout()
    plt.show()

# Main Execution
file_path = "C:/Users/mrhim/OneDrive/Desktop/Lab Session Data.xlsx"
stock_data, thyroid_data = load_data(file_path, "IRCTC Stock Price", "thyroid0387_UCI")

thyroid_data, numeric_cols = clean_data(thyroid_data)
thyroid_data = normalize_data(thyroid_data, numeric_cols)

sim_matrix = generate_similarity_matrix(thyroid_data, numeric_cols)
plot_similarity_matrix(sim_matrix)
